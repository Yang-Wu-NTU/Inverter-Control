This folder contains the data to train and test NNLI.

The row number is the sample number in each dataset, while the column number contains 80 sampled active power (P) and 80 sampled reactive power (Q). Please use the first 80 columns for training and testing.